
import React, { useState } from 'react';
import type { RashifalData } from './types';
import { getRashifalByName } from './services/geminiService';
import Header from './components/Header';
import NameInputForm from './components/NameInputForm';
import RashifalDisplay from './components/RashifalDisplay';
import Loader from './components/Loader';
import ErrorMessage from './components/ErrorMessage';

const App: React.FC = () => {
  const [name, setName] = useState<string>('');
  const [rashifalData, setRashifalData] = useState<RashifalData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsLoading(true);
    setError(null);
    setRashifalData(null);

    try {
      const data = await getRashifalByName(name);
      setRashifalData(data);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/30 to-slate-900 text-white font-sans flex flex-col items-center p-4 sm:p-6">
       <style>
        {`
          @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fade-in 0.5s ease-out forwards;
          }
        `}
      </style>
      <div className="w-full max-w-4xl flex flex-col items-center pt-10 sm:pt-20">
        <Header />
        <NameInputForm 
          name={name}
          setName={setName}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
        
        <div className="w-full flex justify-center mt-4">
            {isLoading && <Loader />}
            {error && <ErrorMessage message={error} />}
            {rashifalData && <RashifalDisplay data={rashifalData} />}
        </div>
      </div>
    </div>
  );
};

export default App;
