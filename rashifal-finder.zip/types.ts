
export interface RashifalData {
  rashi: string;
  rashifal: string;
}
