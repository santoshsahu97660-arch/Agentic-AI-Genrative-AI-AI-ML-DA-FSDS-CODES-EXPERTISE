
import React from 'react';

const StarIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-amber-300" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279L12 18.896l-7.416 4.517 1.48-8.279L0 9.306l8.332-1.151z"/>
  </svg>
);

const Header: React.FC = () => {
  return (
    <header className="flex flex-col items-center justify-center text-center p-4">
        <StarIcon />
        <h1 className="text-4xl sm:text-5xl font-bold text-white tracking-tight mt-2">
            Rashifal Finder
        </h1>
        <p className="mt-2 text-lg text-slate-400">
            Apne naam se apna rashifal jaanein
        </p>
    </header>
  );
};

export default Header;
