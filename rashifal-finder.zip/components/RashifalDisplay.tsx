
import React from 'react';
import type { RashifalData } from '../types';

interface RashifalDisplayProps {
  data: RashifalData;
}

const RashifalDisplay: React.FC<RashifalDisplayProps> = ({ data }) => {
  return (
    <div className="w-full max-w-2xl mt-8 p-6 bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl shadow-lg animate-fade-in">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-amber-400 tracking-wide">{data.rashi}</h2>
        <p className="text-lg text-slate-300 mt-1">(Your Zodiac Sign)</p>
      </div>
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-white mb-2">Aaj ka Rashifal:</h3>
        <p className="text-slate-300 text-lg leading-relaxed">
          {data.rashifal}
        </p>
      </div>
    </div>
  );
};

export default RashifalDisplay;
