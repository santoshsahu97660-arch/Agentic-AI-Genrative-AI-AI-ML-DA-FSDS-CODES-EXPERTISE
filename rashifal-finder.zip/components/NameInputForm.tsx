
import React from 'react';

interface NameInputFormProps {
  name: string;
  setName: (name: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
}

const NameInputForm: React.FC<NameInputFormProps> = ({ name, setName, onSubmit, isLoading }) => {
  return (
    <form onSubmit={onSubmit} className="w-full max-w-md mt-8">
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Apna Naam Yahan Likhein..."
          className="w-full px-5 py-3 text-lg text-white bg-slate-800 border-2 border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-300"
          disabled={isLoading}
          required
        />
        <button
          type="submit"
          className="w-full sm:w-auto px-6 py-3 text-lg font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 transition-all duration-300 disabled:bg-purple-900 disabled:cursor-not-allowed disabled:opacity-70 flex items-center justify-center"
          disabled={isLoading}
        >
          {isLoading ? 'Khoj Raha Hai...' : 'Rashifal Pata Karein'}
        </button>
      </div>
    </form>
  );
};

export default NameInputForm;
