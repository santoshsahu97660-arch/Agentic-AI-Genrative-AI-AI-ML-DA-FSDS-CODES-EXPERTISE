
import { GoogleGenAI, Type } from "@google/genai";
import { RashifalData } from '../types';

export async function getRashifalByName(name: string): Promise<RashifalData> {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the Indian name '${name}', determine the corresponding zodiac sign (Rashi) according to Vedic astrology. Then, provide today's horoscope (Rashifal) for that sign. The rashifal should be a single, engaging paragraph.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rashi: {
              type: Type.STRING,
              description: 'The Vedic zodiac sign (Rashi) corresponding to the name.'
            },
            rashifal: {
              type: Type.STRING,
              description: "Today's horoscope (Rashifal) for that sign."
            }
          },
          required: ["rashi", "rashifal"]
        },
      },
    });

    const jsonString = response.text.trim();
    const parsedData: RashifalData = JSON.parse(jsonString);
    return parsedData;

  } catch (error) {
    console.error("Error fetching Rashifal from Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to get Rashifal. Gemini API error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching Rashifal data.");
  }
}
