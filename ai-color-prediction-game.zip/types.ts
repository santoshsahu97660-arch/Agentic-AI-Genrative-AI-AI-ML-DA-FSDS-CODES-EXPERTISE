
export enum GameColor {
  GREEN = 'GREEN',
  VIOLET = 'VIOLET',
  RED = 'RED',
}

export interface GameResult {
  id: number;
  color: GameColor;
  number: number;
}

export type Prediction = GameColor | 'Thinking...' | 'Error' | null;
