
import React, { useState } from 'react';
import { GameColor, Prediction } from '../types';
import { COLORS, TEXT_COLORS } from '../constants';

interface PredictionControlsProps {
  onPlaceBet: (color: GameColor, amount: number) => void;
  onGetPrediction: () => void;
  isPredicting: boolean;
  aiPrediction: Prediction;
  gamePhase: 'betting' | 'waiting';
  currentBet: { color: GameColor; amount: number } | null;
}

const PredictionControls: React.FC<PredictionControlsProps> = ({ onPlaceBet, onGetPrediction, isPredicting, aiPrediction, gamePhase, currentBet }) => {
  const [betAmount, setBetAmount] = useState<number>(100);

  const handleBet = (color: GameColor) => {
    if (gamePhase === 'betting' && !currentBet) {
      onPlaceBet(color, betAmount);
    }
  };

  const getPredictionDisplay = () => {
    if (!aiPrediction) return null;
    if (aiPrediction === 'Thinking...' || aiPrediction === 'Error') {
      return (
        <div className="flex items-center space-x-2">
          {aiPrediction === 'Thinking...' && <div className="w-4 h-4 border-2 border-dashed rounded-full animate-spin border-yellow-400"></div>}
          <span className="text-yellow-400">{aiPrediction}</span>
        </div>
      );
    }
    return (
      <div className="flex items-center space-x-2">
        <span className="font-semibold">AI Predicts:</span>
        <span className={`font-bold text-lg ${TEXT_COLORS[aiPrediction]}`}>{aiPrediction}</span>
        <div className={`w-4 h-4 rounded-full ${COLORS[aiPrediction]}`}></div>
      </div>
    );
  };
  
  const betAmounts = [10, 100, 1000, 10000];

  return (
    <div className="bg-gray-700/50 rounded-xl p-4 space-y-4">
      <div className="flex justify-center items-center space-x-4">
        <button
          onClick={onGetPrediction}
          disabled={isPredicting || gamePhase === 'waiting'}
          className="flex-1 bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          <span>Get AI Prediction</span>
           <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" /><path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" /></svg>
        </button>
        <div className="flex-1 text-center h-12 flex items-center justify-center bg-gray-900/50 rounded-lg">
            {getPredictionDisplay()}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {(Object.keys(GameColor) as Array<keyof typeof GameColor>).map((colorKey) => (
          <button
            key={colorKey}
            onClick={() => handleBet(GameColor[colorKey])}
            disabled={gamePhase === 'waiting' || !!currentBet}
            className={`font-bold py-4 rounded-lg transition-all duration-200 text-white shadow-md text-lg
              ${colorKey === 'GREEN' ? 'bg-green-500 hover:bg-green-600' : ''}
              ${colorKey === 'VIOLET' ? 'bg-violet-500 hover:bg-violet-600' : ''}
              ${colorKey === 'RED' ? 'bg-red-500 hover:bg-red-600' : ''}
              disabled:opacity-50 disabled:cursor-not-allowed
              ${currentBet?.color === GameColor[colorKey] ? 'ring-4 ring-yellow-400' : ''}
            `}
          >
            Join {colorKey}
          </button>
        ))}
      </div>
      
      <div className='bg-gray-900/50 rounded-lg p-2'>
        <div className='flex items-center justify-between'>
          <span className="font-semibold text-gray-300">Amount</span>
          <div className="flex items-center space-x-2">
            {betAmounts.map(amount => (
                <button key={amount} onClick={() => setBetAmount(amount)} className={`px-4 py-1 text-sm rounded-md transition-colors ${betAmount === amount ? 'bg-yellow-500 text-gray-900 font-bold' : 'bg-gray-600 text-white'}`}>
                    {amount/1000 > 0 ? `${amount/1000}k` : amount}
                </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictionControls;
