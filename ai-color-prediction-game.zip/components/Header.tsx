
import React from 'react';

interface HeaderProps {
  balance: string;
}

const Header: React.FC<HeaderProps> = ({ balance }) => {
  const handleWithdrawClick = () => {
    alert("This is a simulation. No real withdrawals are possible.");
  };

  return (
    <header className="bg-gray-700 rounded-xl p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl md:text-2xl font-bold text-yellow-400 tracking-wider">AI Color Predictor</h1>
        <div className="flex items-center space-x-2">
            <button className="bg-blue-500 hover:bg-blue-600 text-white text-xs font-semibold py-1 px-3 rounded-full transition-colors">Rules</button>
            <button className="bg-green-500 hover:bg-green-600 text-white text-xs font-semibold py-1 px-3 rounded-full transition-colors">Reload</button>
        </div>
      </div>
      <div className="bg-gray-900/50 rounded-lg p-4 flex justify-between items-center">
        <div>
          <p className="text-sm text-gray-400">Balance</p>
          <p className="text-2xl font-bold text-white">{balance}</p>
        </div>
        <div className="flex space-x-2">
            <button className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold py-2 px-4 rounded-lg transition-colors">Deposit</button>
            <button onClick={handleWithdrawClick} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg transition-colors">Withdraw</button>
        </div>
      </div>
       <div className="text-center mt-2">
        <p className="text-xs text-red-400 font-semibold">Disclaimer: This is a simulation for entertainment purposes only.</p>
      </div>
    </header>
  );
};

export default Header;
