
import React from 'react';
import { GameResult } from '../types';
import { COLORS } from '../constants';

interface ResultHistoryProps {
  history: GameResult[];
}

const ResultHistory: React.FC<ResultHistoryProps> = ({ history }) => {
  return (
    <div className="bg-gray-700/50 rounded-xl p-4">
      <h2 className="text-lg font-bold mb-3 text-center text-gray-300">Game History</h2>
      <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
        {history.map((result) => (
          <div key={result.id} className="flex flex-col items-center justify-center aspect-square rounded-lg p-1 bg-gray-900/50">
            <span className={`w-6 h-6 flex items-center justify-center rounded-full text-white font-bold text-sm ${COLORS[result.color]}`}>
              {result.number}
            </span>
            <span className='text-xs text-gray-400 mt-1'>{result.color.charAt(0)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResultHistory;
