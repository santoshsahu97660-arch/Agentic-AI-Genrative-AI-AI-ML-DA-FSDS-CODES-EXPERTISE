
import React from 'react';

interface CountdownTimerProps {
  periodId: number;
  timeLeft: number;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ periodId, timeLeft }) => {
  const progress = (timeLeft / 30) * 100;

  return (
    <div className="bg-gray-700/50 rounded-xl p-4 flex justify-between items-center">
      <div>
        <p className="text-lg font-bold text-yellow-400">Win Go 1Min</p>
        <p className="text-gray-400 text-sm">{periodId}</p>
      </div>
      <div className="flex flex-col items-center">
        <p className="text-gray-400 text-sm">Time remaining</p>
        <div className="relative w-24 h-24 flex items-center justify-center">
           <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 36 36">
            <path
              className="text-gray-600"
              d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            />
            <path
              className="text-yellow-400"
              d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeDasharray={`${progress}, 100`}
              transform="rotate(90 18 18)"
            />
          </svg>
           <span className="text-4xl font-bold text-white z-10">{timeLeft}</span>
        </div>
      </div>
    </div>
  );
};

export default CountdownTimer;
