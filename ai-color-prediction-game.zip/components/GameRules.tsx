
import React from 'react';

const GameRules: React.FC = () => {
    return (
        <div className="bg-gray-700/50 rounded-xl p-4 text-xs text-gray-400">
            <h3 className="font-bold text-center text-gray-300 mb-2">How It Works (Simulation)</h3>
            <ul className="list-disc list-inside space-y-1">
                <li>Select a color (Green, Violet, Red) and place a bet within 30 seconds.</li>
                <li>If the result is your color, you win. Green/Red bets win 2x. Violet bets win 4.5x.</li>
                <li>
                    <strong>Green:</strong> Numbers 1, 3, 7, 9.
                </li>
                <li>
                    <strong>Red:</strong> Numbers 2, 4, 6, 8.
                </li>
                 <li>
                    <strong>Violet:</strong> Appears with number 0 (Red+Violet) and 5 (Green+Violet).
                </li>
                <li>Use the "Get AI Prediction" button to ask Gemini to analyze the history and suggest the next color.</li>
            </ul>
        </div>
    );
}

export default GameRules;
