
import React from 'react';

interface BetResultPopupProps {
  result: {
    status: 'win' | 'loss';
    amount: number;
  };
}

const BetResultPopup: React.FC<BetResultPopupProps> = ({ result }) => {
  const isWin = result.status === 'win';
  const formattedAmount = new Intl.NumberFormat('en-IN').format(result.amount);
  
  return (
    <div className="fixed top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 animate-fade-in-out">
      <div
        className={`rounded-xl shadow-2xl px-8 py-6 text-center text-white
          ${isWin ? 'bg-gradient-to-br from-green-500 to-green-700' : 'bg-gradient-to-br from-red-500 to-red-700'}`}
      >
        <h3 className="text-3xl font-extrabold mb-2">{isWin ? 'You Won!' : 'You Lost'}</h3>
        <p className="text-lg font-semibold">
          {isWin ? `+ ₹${formattedAmount}` : `- ₹${formattedAmount}`}
        </p>
      </div>
      <style>{`
        @keyframes fade-in-out {
          0% { opacity: 0; transform: translate(-50%, -70%); }
          20% { opacity: 1; transform: translate(-50%, -50%); }
          80% { opacity: 1; transform: translate(-50%, -50%); }
          100% { opacity: 0; transform: translate(-50%, -30%); }
        }
        .animate-fade-in-out {
          animation: fade-in-out 3s ease-in-out forwards;
        }
      `}</style>
    </div>
  );
};

export default BetResultPopup;
