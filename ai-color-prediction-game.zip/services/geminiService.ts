
import { GoogleGenAI } from "@google/genai";
import { GameColor, GameResult } from '../types';

export const predictNextColor = async (history: GameResult[]): Promise<GameColor | null> => {
  if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
    return null;
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const historyString = history.map(result => result.color).join(', ');

  const prompt = `You are a pattern recognition expert for a color prediction game. The possible outcomes are GREEN, VIOLET, and RED. Based on the following sequence of previous results, predict the most likely next color. Provide ONLY the color name as your answer (e.g., "GREEN"). Do not add any explanation.

History (oldest to newest): ${historyString}

Next color:`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const predictionText = response.text.trim().toUpperCase();

    if (Object.values(GameColor).includes(predictionText as GameColor)) {
      return predictionText as GameColor;
    } else {
      console.warn("Gemini returned an invalid color:", predictionText);
      return null;
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return null;
  }
};
