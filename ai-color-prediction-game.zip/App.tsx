
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GameColor, GameResult, Prediction } from './types';
import { COUNTDOWN_SECONDS, INITIAL_BALANCE, NUMBER_COLORS } from './constants';
import { predictNextColor } from './services/geminiService';
import Header from './components/Header';
import CountdownTimer from './components/CountdownTimer';
import ResultHistory from './components/ResultHistory';
import PredictionControls from './components/PredictionControls';
import BetResultPopup from './components/BetResultPopup';
import GameRules from './components/GameRules';

const App: React.FC = () => {
  const [balance, setBalance] = useState<number>(INITIAL_BALANCE);
  const [timeLeft, setTimeLeft] = useState<number>(COUNTDOWN_SECONDS);
  const [history, setHistory] = useState<GameResult[]>([]);
  const [currentBet, setCurrentBet] = useState<{ color: GameColor; amount: number } | null>(null);
  const [aiPrediction, setAiPrediction] = useState<Prediction>(null);
  const [isPredicting, setIsPredicting] = useState<boolean>(false);
  const [gamePhase, setGamePhase] = useState<'betting' | 'waiting'>('betting');
  const [periodId, setPeriodId] = useState<number>(new Date().getMinutes() * 100 + new Date().getSeconds());
  const [betResult, setBetResult] = useState<{ status: 'win' | 'loss'; amount: number } | null>(null);

  const generateResult = useCallback(() => {
    const number = Math.floor(Math.random() * 10);
    let color = NUMBER_COLORS[number];
     // Handle special cases for 0 and 5, which can be green/red as well
    if (number === 0) {
        color = GameColor.RED; // As per game rules, 0 is Red + Violet
    } else if (number === 5) {
        color = GameColor.GREEN; // 5 is Green + Violet
    }
    
    const newResult: GameResult = { id: Date.now(), color, number };
    
    setHistory(prev => [...prev, newResult].slice(-50)); // Keep last 50 results

    // Settle bet
    if (currentBet) {
      let won = false;
      let payout = 0;
      
      const isVioletResult = newResult.number === 0 || newResult.number === 5;

      if (currentBet.color === newResult.color) {
        won = true;
        payout = currentBet.amount * 2;
      } else if (currentBet.color === GameColor.VIOLET && isVioletResult) {
        won = true;
        payout = currentBet.amount * 4.5;
      }

      if (won) {
        setBalance(prev => prev + payout);
        setBetResult({ status: 'win', amount: payout });
      } else {
        setBetResult({ status: 'loss', amount: currentBet.amount });
      }
    }
    
    setCurrentBet(null);
  }, [currentBet]);

  useEffect(() => {
    if (history.length === 0) {
        // Generate initial history
        let initialHistory: GameResult[] = [];
        for (let i = 0; i < 10; i++) {
            const number = Math.floor(Math.random() * 10);
            let color = NUMBER_COLORS[number];
            if (number === 0) color = GameColor.RED;
            if (number === 5) color = GameColor.GREEN;
            initialHistory.push({ id: Date.now() + i, color, number });
        }
        setHistory(initialHistory);
    }
  }, [history.length]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setGamePhase('waiting');
          generateResult();
          setPeriodId(new Date().getMinutes() * 100 + new Date().getSeconds());
          setAiPrediction(null);
          setTimeout(() => setGamePhase('betting'), 3000);
          return COUNTDOWN_SECONDS;
        }
        if (prev <= 5) {
            setGamePhase('waiting');
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [generateResult]);

  const handleGetPrediction = useCallback(async () => {
    setIsPredicting(true);
    setAiPrediction('Thinking...');
    const prediction = await predictNextColor(history);
    setAiPrediction(prediction || 'Error');
    setIsPredicting(false);
  }, [history]);

  const handlePlaceBet = (color: GameColor, amount: number) => {
    if (gamePhase === 'betting' && balance >= amount && amount > 0) {
      setBalance(prev => prev - amount);
      setCurrentBet({ color, amount });
    }
  };

  useEffect(() => {
    if (betResult) {
      const timer = setTimeout(() => setBetResult(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [betResult]);
  
  const formattedBalance = useMemo(() => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(balance), [balance]);

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center p-4 font-sans">
      <div className="w-full max-w-md mx-auto bg-gray-800 rounded-2xl shadow-lg p-2 md:p-4 space-y-4">
        <Header balance={formattedBalance} />
        <CountdownTimer periodId={periodId} timeLeft={timeLeft} />
        <PredictionControls 
          onPlaceBet={handlePlaceBet}
          onGetPrediction={handleGetPrediction}
          isPredicting={isPredicting}
          aiPrediction={aiPrediction}
          gamePhase={gamePhase}
          currentBet={currentBet}
        />
        <ResultHistory history={history} />
        <GameRules />
      </div>
      {betResult && <BetResultPopup result={betResult} />}
    </div>
  );
};

export default App;
