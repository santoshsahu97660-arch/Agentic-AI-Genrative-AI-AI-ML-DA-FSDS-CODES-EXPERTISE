
import { GameColor } from './types';

export const COUNTDOWN_SECONDS = 30;
export const INITIAL_BALANCE = 100000000; // 10 Cr simulation points

export const COLORS: { [key in GameColor]: string } = {
  [GameColor.GREEN]: 'bg-green-500',
  [GameColor.VIOLET]: 'bg-violet-500',
  [GameColor.RED]: 'bg-red-500',
};

export const BORDER_COLORS: { [key in GameColor]: string } = {
  [GameColor.GREEN]: 'border-green-500',
  [GameColor.VIOLET]: 'border-violet-500',
  [GameColor.RED]: 'border-red-500',
};

export const TEXT_COLORS: { [key in GameColor]: string } = {
  [GameColor.GREEN]: 'text-green-500',
  [GameColor.VIOLET]: 'text-violet-500',
  [GameColor.RED]: 'text-red-500',
};

export const NUMBER_COLORS: { [key: number]: GameColor } = {
    1: GameColor.GREEN, 3: GameColor.GREEN, 7: GameColor.GREEN, 9: GameColor.GREEN,
    2: GameColor.RED, 4: GameColor.RED, 6: GameColor.RED, 8: GameColor.RED,
    0: GameColor.VIOLET, 5: GameColor.VIOLET,
};
