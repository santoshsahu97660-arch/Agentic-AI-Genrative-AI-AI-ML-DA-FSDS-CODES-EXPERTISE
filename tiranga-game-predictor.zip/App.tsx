
import React, { useState, useEffect, useCallback } from 'react';
import { HistoryItem, Prediction } from './types';
import { getPrediction } from './services/geminiService';
import CountdownTimer from './components/CountdownTimer';
import PredictionDisplay from './components/PredictionDisplay';
import HistoryTable from './components/HistoryTable';
import { Info, BarChart2 } from 'lucide-react';

const App: React.FC = () => {
  const [periodId, setPeriodId] = useState<bigint>(BigInt('20251106100052250'));
  const [countdown, setCountdown] = useState(30);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateNewPeriod = useCallback(() => {
    setPeriodId(prev => prev + 1n);
    setCountdown(30);
    setPrediction(null);
    if (history.length > 0) {
      // Add a random "actual" result for the completed period to history
      const lastItem = history[0];
      if (!lastItem.actual) {
        const actualNumber = Math.floor(Math.random() * 10);
        let actualColor: 'Green' | 'Red' | 'Violet';
        if (actualNumber === 0) actualColor = 'Violet';
        else if (actualNumber === 5) actualColor = 'Violet';
        else if (actualNumber % 2 === 0) actualColor = 'Red';
        else actualColor = 'Green';

        const updatedHistory = [...history];
        updatedHistory[0] = { ...lastItem, actual: { number: actualNumber, color: actualColor } };
        setHistory(updatedHistory);
      }
    }
  }, [history]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      generateNewPeriod();
    }
  }, [countdown, generateNewPeriod]);

  const handlePrediction = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getPrediction(periodId.toString(), history.slice(0, 5));
      setPrediction(result);
      // Add to history with prediction, actual will be added on next period
      const newHistoryItem: HistoryItem = {
        periodId: periodId.toString(),
        prediction: result,
        actual: null,
      };
      setHistory(prev => [newHistoryItem, ...prev]);

    } catch (err) {
      setError('Failed to get prediction. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const getNumberColorClass = (color: 'Green' | 'Red' | 'Violet') => {
    switch (color) {
        case 'Green': return 'bg-custom-green text-white';
        case 'Red': return 'bg-custom-red text-white';
        case 'Violet': return 'bg-custom-violet text-white';
    }
  };

  return (
    <div className="bg-custom-bg min-h-screen text-custom-text font-sans flex flex-col items-center p-4">
      <div className="w-full max-w-md mx-auto">
        <header className="text-center mb-6">
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">Tiranga Predictor AI</h1>
          <p className="text-custom-text-dark">Your AI-powered game assistant</p>
        </header>

        <main>
          <div className="bg-custom-card rounded-xl shadow-lg p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <BarChart2 className="text-yellow-400" size={20} />
                <span className="font-semibold">Win Go 1Min</span>
              </div>
              <div className="flex items-center space-x-2">
                <Info className="text-blue-400" size={20} />
                <button className="text-sm">Rules</button>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <p className="text-lg font-bold text-green-400">Period</p>
                <p className="text-2xl font-mono">{periodId.toString()}</p>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-red-400">Countdown</p>
                <CountdownTimer seconds={countdown} />
              </div>
            </div>
          </div>
          
          <PredictionDisplay prediction={prediction} isLoading={isLoading} />

          {error && <div className="text-center text-red-500 my-4 p-3 bg-red-500/10 rounded-lg">{error}</div>}

          <div className="fixed bottom-0 left-0 right-0 p-4 bg-custom-bg/80 backdrop-blur-sm border-t border-gray-700 md:relative md:bg-transparent md:border-none md:p-0">
             <button
                onClick={handlePrediction}
                disabled={isLoading || !!prediction || countdown <= 5}
                className="w-full max-w-md mx-auto py-4 px-6 text-lg font-bold text-white rounded-xl shadow-lg transition-all duration-300 ease-in-out
                          bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700
                          disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed disabled:opacity-60
                          focus:outline-none focus:ring-4 focus:ring-green-300"
              >
                {isLoading ? 'Analyzing...' : (prediction ? 'Prediction Received' : (countdown <= 5 ? 'Waiting for Next...' : 'Predict Next Outcome'))}
              </button>
          </div>

          <HistoryTable history={history} />
        </main>
      </div>
    </div>
  );
};

export default App;
