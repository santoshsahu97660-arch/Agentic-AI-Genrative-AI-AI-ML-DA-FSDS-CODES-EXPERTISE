
import React from 'react';
import { Prediction } from '../types';

interface PredictionDisplayProps {
  prediction: Prediction | null;
  isLoading: boolean;
}

const PredictionDisplay: React.FC<PredictionDisplayProps> = ({ prediction, isLoading }) => {
  const getBackgroundColor = (color?: 'Green' | 'Red' | 'Violet') => {
    if (!color) return 'bg-gray-700/50';
    switch (color) {
      case 'Green':
        return 'bg-gradient-to-br from-green-500 to-emerald-600';
      case 'Red':
        return 'bg-gradient-to-br from-red-500 to-rose-600';
      case 'Violet':
        return 'bg-gradient-to-br from-violet-500 to-purple-600';
      default:
        return 'bg-gray-700';
    }
  };

  return (
    <div className="bg-custom-card rounded-xl shadow-lg p-6 mb-6 text-center">
      <h2 className="text-lg font-semibold mb-4 text-custom-text-dark">AI Prediction</h2>
      <div className={`w-40 h-40 mx-auto rounded-full flex items-center justify-center transition-all duration-500 ${getBackgroundColor(prediction?.color)}`}>
        {isLoading ? (
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white"></div>
        ) : prediction ? (
          <div className="text-center text-white">
            <span className="block text-5xl font-bold">{prediction.number}</span>
            <span className="block text-2xl font-semibold">{prediction.color}</span>
          </div>
        ) : (
          <div className="text-center">
            <span className="block text-2xl font-semibold text-custom-text-dark">Waiting...</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default PredictionDisplay;
