
import React from 'react';
import { HistoryItem, Prediction } from '../types';

interface HistoryTableProps {
  history: HistoryItem[];
}

const HistoryTable: React.FC<HistoryTableProps> = ({ history }) => {
    if (history.length === 0) {
        return (
            <div className="mt-8 bg-custom-card rounded-xl shadow-lg p-6 text-center">
                <h3 className="text-xl font-semibold mb-2">Prediction History</h3>
                <p className="text-custom-text-dark">No predictions made yet. Click the button to get your first AI prediction.</p>
            </div>
        );
    }

  const ResultBadge: React.FC<{ result: Prediction | null }> = ({ result }) => {
    if (!result) return <span className="text-sm text-gray-500">Pending</span>;

    let colorClass = '';
    switch (result.color) {
      case 'Green': colorClass = 'bg-custom-green'; break;
      case 'Red': colorClass = 'bg-custom-red'; break;
      case 'Violet': colorClass = 'bg-custom-violet'; break;
    }

    return (
      <div className="flex items-center justify-center space-x-2">
        <span className={`px-3 py-1 text-sm font-bold text-white rounded-full ${colorClass}`}>
          {result.color}
        </span>
        <span className="font-mono text-base">{result.number}</span>
      </div>
    );
  };
  
  const StatusIndicator: React.FC<{item: HistoryItem}> = ({ item }) => {
    if (!item.prediction || !item.actual) {
        return null;
    }

    const isWin = item.prediction.color === item.actual.color || 
                  (item.actual.color === 'Violet' && (item.prediction.color === 'Green' || item.prediction.color === 'Red'));

    return (
        <span className={`text-xs font-bold px-2 py-1 rounded-full ${isWin ? 'text-green-300 bg-green-500/20' : 'text-red-300 bg-red-500/20'}`}>
            {isWin ? 'Win' : 'Loss'}
        </span>
    );
  };


  return (
    <div className="mt-8 bg-custom-card rounded-xl shadow-lg p-4 md:p-6 mb-24 md:mb-0">
      <h3 className="text-xl font-semibold mb-4 text-center">Prediction History</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-custom-text-dark">
          <thead className="text-xs text-custom-text uppercase bg-gray-700/50">
            <tr>
              <th scope="col" className="px-4 py-3">Period</th>
              <th scope="col" className="px-4 py-3 text-center">Prediction</th>
              <th scope="col" className="px-4 py-3 text-center">Actual Result</th>
              <th scope="col" className="px-4 py-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody>
            {history.map((item, index) => (
              <tr key={item.periodId} className={`border-b border-gray-700 ${index % 2 === 0 ? 'bg-custom-card' : 'bg-gray-800/50'}`}>
                <td className="px-4 py-3 font-mono">{item.periodId}</td>
                <td className="px-4 py-3 text-center"><ResultBadge result={item.prediction} /></td>
                <td className="px-4 py-3 text-center"><ResultBadge result={item.actual} /></td>
                <td className="px-4 py-3 text-center"><StatusIndicator item={item} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HistoryTable;
