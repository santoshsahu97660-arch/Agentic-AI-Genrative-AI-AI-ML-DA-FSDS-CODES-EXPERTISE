
import { GoogleGenAI, Type } from "@google/genai";
import { HistoryItem, Prediction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getPrediction = async (
  periodId: string,
  history: HistoryItem[]
): Promise<Prediction> => {
  const historyString = history
    .map(
      (h) =>
        `Period: ${h.periodId}, Predicted: ${h.prediction?.color}-${h.prediction?.number}, Actual: ${h.actual?.color}-${h.actual?.number}`
    )
    .join("\n");

  const prompt = `
    Analyze the patterns in this color prediction game (Tiranga Game).
    The game involves numbers 0-9 and three colors: Green, Red, and Violet.
    - Green is for odd numbers (1, 3, 7, 9).
    - Red is for even numbers (2, 4, 6, 8).
    - Violet appears with 0 and 5. When 0 or 5 is the number, both Red/Green and Violet are considered winning colors.
    
    Current Period ID is ${periodId}.
    
    Here are the recent results:
    ${historyString || "No history available yet."}
    
    Based on trend analysis, statistical probability, and pattern recognition from the provided history, predict the most likely outcome for the current period (${periodId}).
    Your prediction should be a single number from 0 to 9 and its corresponding color. Provide only the JSON object in your response.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            number: {
              type: Type.INTEGER,
              description: "The predicted number from 0 to 9.",
            },
            color: {
              type: Type.STRING,
              description: "The corresponding color: 'Green', 'Red', or 'Violet'.",
              enum: ["Green", "Red", "Violet"],
            },
          },
          required: ["number", "color"],
        },
      },
    });

    const text = response.text.trim();
    const predictionJson = JSON.parse(text);

    // Basic validation
    if (
      typeof predictionJson.number !== 'number' ||
      !['Green', 'Red', 'Violet'].includes(predictionJson.color)
    ) {
      throw new Error('Invalid JSON structure from Gemini');
    }

    return predictionJson as Prediction;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Fallback in case of API error to keep the app functional
    const fallbackNumber = Math.floor(Math.random() * 10);
    let fallbackColor: 'Green' | 'Red' | 'Violet';
    if (fallbackNumber === 0 || fallbackNumber === 5) {
        fallbackColor = 'Violet';
    } else if (fallbackNumber % 2 === 0) {
        fallbackColor = 'Red';
    } else {
        fallbackColor = 'Green';
    }
    return { number: fallbackNumber, color: fallbackColor };
  }
};
