
export type Color = 'Green' | 'Red' | 'Violet';

export interface Prediction {
  number: number;
  color: Color;
}

export interface HistoryItem {
  periodId: string;
  prediction: Prediction | null;
  actual: Prediction | null;
}
