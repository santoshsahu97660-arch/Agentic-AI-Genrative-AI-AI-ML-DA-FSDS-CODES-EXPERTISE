
import React, { useState, useCallback } from 'react';
import ImageUploader from './components/ImageUploader';
import Spinner from './components/Spinner';
import { generateReunifyImage } from './services/geminiService';
import { type ImageData } from './types';

const App: React.FC = () => {
  const [childImage, setChildImage] = useState<ImageData | null>(null);
  const [adultImage, setAdultImage] = useState<ImageData | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!childImage || !adultImage) {
      setError('Please upload both a child photo and an adult photo.');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const resultBase64 = await generateReunifyImage(childImage, adultImage);
      setGeneratedImage(`data:image/png;base64,${resultBase64}`);
    } catch (e) {
      console.error(e);
      setError('Failed to generate the image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [childImage, adultImage]);

  const canGenerate = childImage && adultImage && !isLoading;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-indigo-600 mb-2">
            Reunify
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Merge your past and present. Upload a childhood photo and a recent photo to create a beautiful image of your adult self embracing your younger self.
          </p>
        </header>

        <main>
          <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
              <ImageUploader
                title="Child Photo"
                description="Upload an old photo of yourself as a child."
                onImageUpload={(imageData) => setChildImage(imageData)}
              />
              <ImageUploader
                title="Recent Photo"
                description="Upload a recent photo of yourself as an adult."
                onImageUpload={(imageData) => setAdultImage(imageData)}
              />
            </div>

            <div className="flex justify-center mb-8">
              <button
                onClick={handleGenerate}
                disabled={!canGenerate}
                className={`flex items-center justify-center w-full max-w-md px-8 py-4 text-lg font-semibold text-white rounded-xl transition-all duration-300 ease-in-out
                  ${canGenerate ? 'bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5' : 'bg-gray-400 cursor-not-allowed'}
                `}
              >
                {isLoading ? <Spinner /> : 'Reunify Photos'}
              </button>
            </div>

            <div className="w-full">
              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-center" role="alert">
                  <p>{error}</p>
                </div>
              )}
              <div className="mt-6 bg-gray-100 rounded-lg p-4 min-h-[300px] flex items-center justify-center">
                {isLoading ? (
                  <div className="text-center">
                    <Spinner size="lg"/>
                    <p className="mt-4 text-gray-600">Generating your reunion... this may take a moment.</p>
                  </div>
                ) : generatedImage ? (
                  <div className="w-full max-w-2xl mx-auto">
                     <h3 className="text-2xl font-bold text-center mb-4 text-gray-700">Your Reunify Moment</h3>
                    <img src={generatedImage} alt="Generated" className="rounded-xl shadow-2xl object-contain w-full" />
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p className="mt-2">Your generated image will appear here.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
