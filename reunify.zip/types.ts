
export type ImageData = {
  base64: string;
  mimeType: string;
};
