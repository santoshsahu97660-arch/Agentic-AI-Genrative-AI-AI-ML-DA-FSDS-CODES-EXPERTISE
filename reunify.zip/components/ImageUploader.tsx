
import React, { useState, useRef, useCallback } from 'react';
import { type ImageData } from '../types';

interface ImageUploaderProps {
  title: string;
  description: string;
  onImageUpload: (imageData: ImageData) => void;
}

const fileToBase64 = (file: File): Promise<ImageData> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      const mimeType = result.split(',')[0].split(':')[1].split(';')[0];
      if (base64 && mimeType) {
        resolve({ base64, mimeType });
      } else {
        reject(new Error("Failed to parse file data."));
      }
    };
    reader.onerror = (error) => reject(error);
  });
};


const ImageUploader: React.FC<ImageUploaderProps> = ({ title, description, onImageUpload }) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const imageData = await fileToBase64(file);
        setImagePreview(URL.createObjectURL(file));
        setFileName(file.name);
        onImageUpload(imageData);
      } catch (error) {
        console.error("Error converting file to base64:", error);
        alert("There was an error processing your image. Please try another one.");
      }
    }
  }, [onImageUpload]);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-6 text-center transition-all duration-300 hover:border-indigo-400 hover:bg-indigo-50">
      <h3 className="text-xl font-bold text-gray-700 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 mb-4">{description}</p>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
      />
      <div
        className="mt-4 aspect-square w-full rounded-lg bg-gray-200 flex items-center justify-center cursor-pointer"
        onClick={handleUploadClick}
      >
        {imagePreview ? (
          <img src={imagePreview} alt={fileName} className="w-full h-full object-cover rounded-lg" />
        ) : (
          <div className="text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p className="mt-2 text-sm">Click to upload an image</p>
          </div>
        )}
      </div>
      {fileName && <p className="mt-2 text-xs text-gray-600 truncate">{fileName}</p>}
    </div>
  );
};

export default ImageUploader;
