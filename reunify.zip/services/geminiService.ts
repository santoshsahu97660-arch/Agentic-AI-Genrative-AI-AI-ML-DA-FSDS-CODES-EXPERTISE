
import { GoogleGenAI, Modality } from "@google/genai";
import { type ImageData } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateReunifyImage = async (
  childImage: ImageData,
  adultImage: ImageData
): Promise<string> => {
  const prompt = `Using the two provided images, generate a new, photorealistic image where the person from the recent photo (the adult) is gently hugging the person from the old photo (the child). It should look as if the two versions of the person are interacting naturally in the same space. The lighting should be soft and natural, casting consistent shadows. The background should be a completely smooth, soft white, isolating the subjects. Ensure the final image is a heartwarming and seamless composition.`;

  const childImagePart = {
    inlineData: {
      data: childImage.base64,
      mimeType: childImage.mimeType,
    },
  };

  const adultImagePart = {
    inlineData: {
      data: adultImage.base64,
      mimeType: adultImage.mimeType,
    },
  };

  const textPart = { text: prompt };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [adultImagePart, childImagePart, textPart],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }

    throw new Error('No image data found in the API response.');

  } catch (error) {
    console.error('Gemini API call failed:', error);
    throw new Error('The AI model failed to generate an image.');
  }
};
