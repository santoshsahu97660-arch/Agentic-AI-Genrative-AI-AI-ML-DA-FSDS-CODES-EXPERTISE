import React, { useState, useCallback } from 'react';
import { analyzeRelationshipStatus } from './services/geminiService';
import type { AnalysisResult } from './types';
import { ResultCard } from './components/ResultCard';
import { Loader } from './components/Loader';
import { HeartPulseIcon } from './components/IconComponents';

const App: React.FC = () => {
  const [name, setName] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const analysis = await analyzeRelationshipStatus(name);
      setResult(analysis);
    } catch (err) {
      console.error(err);
      setError('Sorry, the radar is experiencing technical difficulties. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }, [name, isLoading]);

  return (
    <div className="min-h-screen w-full bg-slate-900 text-white flex flex-col items-center justify-between p-4 overflow-x-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-500/30 via-purple-500/20 to-pink-500/30 opacity-50 z-0"></div>
      
      <main className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center flex-grow z-10 py-10">
        <header className="text-center mb-8 animate-fade-in-down">
          <div className="flex justify-center items-center gap-3">
            <HeartPulseIcon className="w-12 h-12 text-pink-400"/>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-pink-400 to-purple-400 text-transparent bg-clip-text">
              Relationship Radar
            </h1>
          </div>
          <p className="text-slate-300 mt-2 text-lg">Naam daalo, status jaano!</p>
        </header>

        <form onSubmit={handleSubmit} className="w-full bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-6 shadow-2xl animate-fade-in-up">
          <label htmlFor="name" className="block text-lg font-medium text-slate-200 mb-2">
            Enter a name...
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="E.g., Rahul, Sameer, Akash..."
            className="w-full p-4 bg-slate-900/70 border border-slate-600 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-300 placeholder:text-slate-500"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !name.trim()}
            className="w-full mt-6 py-3 px-6 text-lg font-semibold rounded-lg bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-500/50 flex items-center justify-center"
          >
            {isLoading ? <Loader /> : 'Analyze Status'}
          </button>
        </form>

        {error && (
          <div className="mt-8 text-center bg-red-500/20 border border-red-500 text-red-300 p-4 rounded-lg animate-fade-in">
            <p>{error}</p>
          </div>
        )}

        {result && (
          <div className="w-full mt-8 animate-fade-in">
            <ResultCard result={result} />
          </div>
        )}
      </main>

      <footer className="text-center text-slate-500 text-sm z-10 pb-4">
        <p>&copy; {new Date().getFullYear()} Relationship Radar. For entertainment purposes only.</p>
      </footer>
    </div>
  );
};

export default App;