
import React from 'react';
import type { AnalysisResult, RelationshipStatus } from '../types';
import { SingleHeartIcon, DoubleHeartIcon, QuestionHeartIcon, SparklesIcon } from './IconComponents';

interface ResultCardProps {
  result: AnalysisResult;
}

const statusConfig: Record<RelationshipStatus, { icon: React.ReactNode; color: string; text: string }> = {
  'Single': {
    icon: <SingleHeartIcon className="w-8 h-8" />,
    color: 'text-green-400',
    text: 'Signal is Green!'
  },
  'In a Relationship': {
    icon: <DoubleHeartIcon className="w-8 h-8" />,
    color: 'text-red-400',
    text: 'Entry Restricted!'
  },
  "It's Complicated": {
    icon: <QuestionHeartIcon className="w-8 h-8" />,
    color: 'text-yellow-400',
    text: 'Proceed with Caution!'
  }
};

export const ResultCard: React.FC<ResultCardProps> = ({ result }) => {
  const config = statusConfig[result.status];
  const probabilityColor = result.probability > 75 ? 'bg-green-500' : result.probability > 40 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="bg-slate-800/60 backdrop-blur-md border border-slate-700 rounded-2xl p-6 shadow-2xl w-full">
      <div className="flex flex-col md:flex-row items-center justify-between mb-4 border-b border-slate-700 pb-4">
        <div className="flex items-center gap-4">
          <div className={config.color}>{config.icon}</div>
          <div>
            <p className="text-slate-400 text-sm">Radar Verdict</p>
            <p className={`text-2xl font-bold ${config.color}`}>{result.status}</p>
          </div>
        </div>
        <div className="text-center mt-4 md:mt-0">
          <p className="text-slate-400 text-sm mb-1">Confidence Score</p>
          <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div className={`${probabilityColor} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${result.probability}%` }}></div>
          </div>
          <p className="text-lg font-semibold mt-1">{result.probability}% Sure</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-200 mb-2">Radar Analysis:</h3>
          <p className="text-slate-300 leading-relaxed">{result.explanation}</p>
        </div>
        
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4 flex items-start gap-3">
          <SparklesIcon className="w-5 h-5 text-purple-400 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-purple-300">Pro Tip:</h4>
            <p className="text-slate-300">{result.advice}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
