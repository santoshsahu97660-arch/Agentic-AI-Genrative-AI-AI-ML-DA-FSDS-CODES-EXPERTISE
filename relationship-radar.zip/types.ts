
export type RelationshipStatus = 'Single' | 'In a Relationship' | "It's Complicated";

export interface AnalysisResult {
  status: RelationshipStatus;
  probability: number;
  explanation: string;
  advice: string;
}
