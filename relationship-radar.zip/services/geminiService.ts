import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    status: {
      type: Type.STRING,
      description: "The relationship status. Must be one of: 'Single', 'In a Relationship', 'It's Complicated'.",
    },
    probability: {
      type: Type.INTEGER,
      description: "A probability percentage (from 0 to 100) of this status being correct.",
    },
    explanation: {
      type: Type.STRING,
      description: "A detailed, witty, and entertaining explanation for your guess, based on the user's input. Write it in a friendly, conversational tone, and can mix in some Hindi/Hinglish to make it more relatable for an Indian audience.",
    },
    advice: {
      type: Type.STRING,
      description: "A short, fun piece of advice for the user based on the analysis. Keep it light-hearted and use Hinglish.",
    }
  },
  required: ['status', 'probability', 'explanation', 'advice'],
};

export const analyzeRelationshipStatus = async (name: string): Promise<AnalysisResult> => {
  try {
    const systemInstruction = `You are 'Relationship Radar,' a fun and witty AI assistant. Your task is to take a person's first name, create a fun, fictional personality profile based on common associations or vibes of that name (be creative and humorous!), and then playfully guess their relationship status based on that FICTIONAL profile. Your tone should be humorous, friendly, and a bit cheeky, like a friend giving advice. Use a mix of English and Hindi (Hinglish) to be more relatable. You MUST NOT try to access any real-world information. The entire output must be based on creative fiction. You MUST return your analysis in the specified JSON format.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the name "${name}", create a fictional personality and guess their relationship status.`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.8,
      },
    });

    const jsonString = response.text.trim();
    const parsedResult: AnalysisResult = JSON.parse(jsonString);
    
    // Validate the parsed result
    if (
      !parsedResult.status ||
      !['Single', 'In a Relationship', "It's Complicated"].includes(parsedResult.status) ||
      typeof parsedResult.probability !== 'number' ||
      typeof parsedResult.explanation !== 'string' ||
      typeof parsedResult.advice !== 'string'
    ) {
      throw new Error("Invalid response structure from AI.");
    }

    return parsedResult;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get analysis from AI.");
  }
};